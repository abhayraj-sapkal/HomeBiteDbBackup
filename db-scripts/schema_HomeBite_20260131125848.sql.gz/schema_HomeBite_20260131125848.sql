--
-- PostgreSQL database dump
--

\restrict nZ4gRuNfnDPip8eSeQ9EFnf4uCb1JOmEfQ96L5vtdZYrwhQ43xfGIFINRJZzEo7

-- Dumped from database version 17.4
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Bookings" (
    "BookingId" integer NOT NULL,
    "HostMealId" integer,
    "MealRequestId" integer,
    "GuestUserId" integer NOT NULL,
    "HostId" integer NOT NULL,
    "EventDate" date NOT NULL,
    "EventTime" time without time zone NOT NULL,
    "TotalAmount" numeric(10,2),
    "PaymentStatus" character varying(50) DEFAULT 'Pending'::character varying,
    "BookingSource" character varying(50) NOT NULL,
    "Status" character varying(50) DEFAULT 'Pending'::character varying,
    "CreatedAt" timestamp without time zone DEFAULT now(),
    "UpdatedAt" timestamp without time zone DEFAULT now(),
    "NoOfGuest" integer,
    "DiningTypeId" integer
);


--
-- Name: Bookings_BookingId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Bookings_BookingId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Bookings_BookingId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Bookings_BookingId_seq" OWNED BY public."Bookings"."BookingId";


--
-- Name: Cuisines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Cuisines" (
    "CuisineId" integer NOT NULL,
    "CuisineName" character varying(100) NOT NULL,
    "CuisineImageUrl" text,
    "IsActive" boolean DEFAULT true NOT NULL,
    "OrderPreference" integer DEFAULT 0,
    "IsDeleted" boolean DEFAULT false NOT NULL,
    "CreatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "UpdatedAt" timestamp without time zone
);


--
-- Name: Cuisines_CuisineId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Cuisines_CuisineId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Cuisines_CuisineId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Cuisines_CuisineId_seq" OWNED BY public."Cuisines"."CuisineId";


--
-- Name: HostMeals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HostMeals" (
    "HostMealId" integer NOT NULL,
    "HostId" integer NOT NULL,
    "CuisineId" integer,
    "DishName" character varying(250) NOT NULL,
    "EventDate" date,
    "EventStartTime" time without time zone,
    "EventEndTime" time without time zone,
    "BookBeforeDate" date,
    "BookBeforeTime" time without time zone,
    "Price" numeric(10,2) NOT NULL,
    "Currency" character varying(8) DEFAULT 'INR'::character varying,
    "MealImage" text,
    "MaximumGuest" integer DEFAULT 1,
    "Description" text,
    "IsActive" boolean DEFAULT true NOT NULL,
    "IsDeleted" boolean DEFAULT false NOT NULL,
    "CreatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "UpdatedAt" timestamp without time zone,
    "IsDineIn" boolean DEFAULT false NOT NULL,
    "IsHomeDelivery" boolean DEFAULT false NOT NULL,
    "IsTakeAway" boolean DEFAULT false NOT NULL,
    "MealImageUrl" text,
    CONSTRAINT "HostMeals_MaximumGuest_check" CHECK (("MaximumGuest" >= 1)),
    CONSTRAINT "HostMeals_Price_check" CHECK (("Price" >= (0)::numeric))
);


--
-- Name: HostMeals_HostMealId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public."HostMeals" ALTER COLUMN "HostMealId" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."HostMeals_HostMealId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: HostRatings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HostRatings" (
    "RatingId" integer NOT NULL,
    "HostId" integer NOT NULL,
    "GuestId" integer NOT NULL,
    "BookingId" integer,
    "ValueForMoney" smallint NOT NULL,
    "Hygiene" smallint NOT NULL,
    "Food" smallint NOT NULL,
    "OverallRating" numeric(3,2) GENERATED ALWAYS AS ((((("ValueForMoney" + "Hygiene") + "Food"))::numeric / 3.0)) STORED,
    "ReviewComment" text,
    "CreatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "UpdatedAt" timestamp without time zone,
    "IsActive" boolean DEFAULT true NOT NULL,
    "IsDeleted" boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_food CHECK ((("Food" >= 1) AND ("Food" <= 5))),
    CONSTRAINT chk_hygiene CHECK ((("Hygiene" >= 1) AND ("Hygiene" <= 5))),
    CONSTRAINT chk_value_for_money CHECK ((("ValueForMoney" >= 1) AND ("ValueForMoney" <= 5)))
);


--
-- Name: HostRatings_RatingId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."HostRatings_RatingId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: HostRatings_RatingId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."HostRatings_RatingId_seq" OWNED BY public."HostRatings"."RatingId";


--
-- Name: Hosts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Hosts" (
    "HostId" integer NOT NULL,
    "UserId" integer NOT NULL,
    "FoodLicence" text,
    "IdProof" text,
    "IsDeleted" boolean DEFAULT false NOT NULL,
    "CreatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "UpdatedAt" timestamp without time zone,
    "KitchenName" character varying(255),
    "HostDescription" text,
    "IsApproved" boolean DEFAULT false,
    "IsRejected" boolean DEFAULT false,
    "RejectedReasonId" integer,
    "OptionalReason" text
);


--
-- Name: Hosts_HostId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public."Hosts" ALTER COLUMN "HostId" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Hosts_HostId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: MasterDiningType; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MasterDiningType" (
    "DiningTypeId" integer NOT NULL,
    "DiningType" character varying(100) NOT NULL,
    "IsDeleted" boolean DEFAULT false NOT NULL,
    "CreatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "UpdatedAt" timestamp without time zone
);


--
-- Name: MasterDiningType_DiningTypeId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."MasterDiningType_DiningTypeId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: MasterDiningType_DiningTypeId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."MasterDiningType_DiningTypeId_seq" OWNED BY public."MasterDiningType"."DiningTypeId";


--
-- Name: MasterReasonCategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MasterReasonCategory" (
    "ReasonCategoryId" integer NOT NULL,
    "CategoryName" character varying(255) NOT NULL,
    "CreatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "IsDeleted" boolean DEFAULT false NOT NULL
);


--
-- Name: MasterReasonCategory_ReasonCategoryId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."MasterReasonCategory_ReasonCategoryId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: MasterReasonCategory_ReasonCategoryId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."MasterReasonCategory_ReasonCategoryId_seq" OWNED BY public."MasterReasonCategory"."ReasonCategoryId";


--
-- Name: MasterRoles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MasterRoles" (
    "RoleId" integer NOT NULL,
    "RoleName" character varying(50) NOT NULL,
    "IsDeleted" boolean DEFAULT false NOT NULL,
    "CreatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "UpdatedAt" timestamp(3) without time zone
);


--
-- Name: MealRequests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MealRequests" (
    "MealRequestId" integer NOT NULL,
    "GuestUserId" integer NOT NULL,
    "CuisineId" integer,
    "DishName" character varying(250) NOT NULL,
    "DiningId" integer,
    "EventDate" date,
    "EventTime" time without time zone,
    "NoOfGuest" integer DEFAULT 1,
    "Description" text,
    "IsAccepted" boolean DEFAULT false NOT NULL,
    "IsDeleted" boolean DEFAULT false NOT NULL,
    "CreatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "UpdatedAt" timestamp without time zone,
    CONSTRAINT "MealRequests_NoOfGuest_check" CHECK (("NoOfGuest" >= 1))
);


--
-- Name: MealRequests_MealRequestId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public."MealRequests" ALTER COLUMN "MealRequestId" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."MealRequests_MealRequestId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: MediaStorage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MediaStorage" (
    "MediaStorageId" integer NOT NULL,
    "UserId" integer,
    "MediaName" character varying(50) NOT NULL,
    "MediaType" character varying(50),
    "MediaBlobId" text NOT NULL,
    "MediaURL" text NOT NULL,
    "CreatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "IsActive" boolean DEFAULT true NOT NULL
);


--
-- Name: MediaStorage_MediaStorageId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."MediaStorage_MediaStorageId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: MediaStorage_MediaStorageId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."MediaStorage_MediaStorageId_seq" OWNED BY public."MediaStorage"."MediaStorageId";


--
-- Name: RejectionReasons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RejectionReasons" (
    "ReasonId" integer NOT NULL,
    "ReasonCategoryId" integer NOT NULL,
    "ReasonText" text NOT NULL,
    "CreatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "IsDeleted" boolean DEFAULT false NOT NULL
);


--
-- Name: RejectionReasons_ReasonId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."RejectionReasons_ReasonId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: RejectionReasons_ReasonId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."RejectionReasons_ReasonId_seq" OWNED BY public."RejectionReasons"."ReasonId";


--
-- Name: RequestQuotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RequestQuotes" (
    "QuoteId" integer NOT NULL,
    "MealRequestId" integer NOT NULL,
    "HostId" integer NOT NULL,
    "QuotedPrice" numeric(10,2) NOT NULL,
    "Currency" character varying(8) DEFAULT 'INR'::character varying,
    "Message" text,
    "Status" character varying(100) DEFAULT 'Offered'::character varying NOT NULL,
    "ValidUntil" timestamp without time zone,
    "CreatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "UpdatedAt" timestamp without time zone,
    "IsDeleted" boolean DEFAULT true,
    CONSTRAINT "RequestQuotes_QuotedPrice_check" CHECK (("QuotedPrice" >= (0)::numeric))
);


--
-- Name: RequestQuotes_QuoteId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public."RequestQuotes" ALTER COLUMN "QuoteId" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."RequestQuotes_QuoteId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: UserAddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UserAddress" (
    "AddressId" integer NOT NULL,
    "UserId" integer NOT NULL,
    "FlatHouseNo" character varying(100) NOT NULL,
    "BuildingName" character varying(150) NOT NULL,
    "StreetLocality" character varying(150) NOT NULL,
    "Landmark" character varying(150),
    "Pincode" character varying(10) NOT NULL,
    "State" character varying(100) NOT NULL,
    "CreatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "UpdatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: UserAddress_AddressId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."UserAddress_AddressId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: UserAddress_AddressId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."UserAddress_AddressId_seq" OWNED BY public."UserAddress"."AddressId";


--
-- Name: Users_UserId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Users_UserId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Users" (
    "UserId" integer DEFAULT nextval('public."Users_UserId_seq"'::regclass) NOT NULL,
    "FirstName" character varying(100),
    "LastName" character varying(100),
    "Email" character varying(255),
    "PhoneNumber" character varying(20),
    "RoleId" integer,
    "PasswordHash" character varying(255),
    "Gender" character varying(20),
    "Country" character varying(255),
    "ProfilePhotoUrl" text,
    "IsEmailVerified" boolean DEFAULT false NOT NULL,
    "IsPhoneNumberVerified" boolean DEFAULT false NOT NULL,
    "IsDeactivate" boolean DEFAULT false NOT NULL,
    "CreatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "UpdatedAt" timestamp(3) without time zone DEFAULT now(),
    "DeactivatedBy" integer,
    "DisplayName" text,
    "CountryCode" text,
    "DialCode" character varying
);


--
-- Name: Bookings BookingId; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Bookings" ALTER COLUMN "BookingId" SET DEFAULT nextval('public."Bookings_BookingId_seq"'::regclass);


--
-- Name: Cuisines CuisineId; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cuisines" ALTER COLUMN "CuisineId" SET DEFAULT nextval('public."Cuisines_CuisineId_seq"'::regclass);


--
-- Name: HostRatings RatingId; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HostRatings" ALTER COLUMN "RatingId" SET DEFAULT nextval('public."HostRatings_RatingId_seq"'::regclass);


--
-- Name: MasterDiningType DiningTypeId; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MasterDiningType" ALTER COLUMN "DiningTypeId" SET DEFAULT nextval('public."MasterDiningType_DiningTypeId_seq"'::regclass);


--
-- Name: MasterReasonCategory ReasonCategoryId; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MasterReasonCategory" ALTER COLUMN "ReasonCategoryId" SET DEFAULT nextval('public."MasterReasonCategory_ReasonCategoryId_seq"'::regclass);


--
-- Name: MediaStorage MediaStorageId; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MediaStorage" ALTER COLUMN "MediaStorageId" SET DEFAULT nextval('public."MediaStorage_MediaStorageId_seq"'::regclass);


--
-- Name: RejectionReasons ReasonId; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RejectionReasons" ALTER COLUMN "ReasonId" SET DEFAULT nextval('public."RejectionReasons_ReasonId_seq"'::regclass);


--
-- Name: UserAddress AddressId; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserAddress" ALTER COLUMN "AddressId" SET DEFAULT nextval('public."UserAddress_AddressId_seq"'::regclass);


--
-- Data for Name: Bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Bookings" ("BookingId", "HostMealId", "MealRequestId", "GuestUserId", "HostId", "EventDate", "EventTime", "TotalAmount", "PaymentStatus", "BookingSource", "Status", "CreatedAt", "UpdatedAt", "NoOfGuest", "DiningTypeId") FROM stdin;
7	0	1	71	3	2025-12-17	09:21:00	1930.00	PAID	REQUEST_QUOTE	CONFIRMED	2025-12-17 06:34:20.003933	2025-12-17 06:34:20.003933	\N	\N
4	0	1	71	3	2025-12-17	09:12:00	1500.00	PAID	REQUEST_QUOTE	CANCELLED	2025-12-17 06:28:07.388523	2025-12-17 06:28:07.388523	\N	\N
8	0	1	71	3	2025-12-17	09:21:00	1930.00	PAID	REQUEST_QUOTE	COMPLETED	2025-12-17 06:42:00.288985	2025-12-17 06:42:00.288985	\N	\N
9	9	0	71	3	2025-12-19	08:21:00	120.00	PAID	HOST_MEAL	CONFIRMED	2025-12-19 09:50:41.254232	2025-12-19 09:50:41.254232	20	2
14	7	0	71	3	2025-12-19	12:00:00	5960.00	PAID	HOST_MEAL	CONFIRMED	2025-12-19 10:59:03.493582	2025-12-19 10:59:03.493582	3	1
15	9	0	71	3	2025-12-19	12:00:00	1957.00	PAID	HOST_MEAL	CONFIRMED	2025-12-19 12:23:44.983032	2025-12-19 12:23:44.983032	8	1
16	7	0	71	3	2025-12-24	12:00:00	3973.00	PAID	HOST_MEAL	CONFIRMED	2025-12-24 06:38:44.245462	2025-12-24 06:38:44.245462	2	1
17	2	2	71	3	2025-12-13	09:02:00	126.00	PAID	REQUEST_QUOTE	CONFIRMED	2025-12-24 06:44:29.180276	2025-12-24 06:44:29.180276	\N	\N
\.


--
-- Data for Name: Cuisines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Cuisines" ("CuisineId", "CuisineName", "CuisineImageUrl", "IsActive", "OrderPreference", "IsDeleted", "CreatedAt", "UpdatedAt") FROM stdin;
8	add	\N	f	0	t	2025-12-11 05:16:40.468834	\N
9	ghabn2	\N	f	0	t	2025-12-11 09:51:48.071494	\N
5	Maharastrian	\N	t	1	f	2025-11-28 09:31:17.940228	\N
6	Maharastrian	\N	t	1	f	2025-11-28 13:19:39.649767	\N
3	Punjabi	\N	f	0	f	2025-11-24 12:43:24.87831	\N
4	Punjabi	https://safroo.blob.core.windows.net/cuisine-image/69e149a1-b7c5-43a4-91b8-45be53bf7018.avif	t	0	f	2025-11-24 12:44:58.104074	\N
7	Gujrati	\N	t	0	f	2025-12-10 11:05:43.056273	\N
10	Italian	\N	t	5	f	2025-12-24 06:25:56.362989	\N
11	French	https://blobstoragehomebite.blob.core.windows.net/cuisine-image/886fbfae-b719-497f-8b96-9223be6156b1.png	t	1	f	2025-12-26 09:52:29.269901	\N
\.


--
-- Data for Name: HostMeals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."HostMeals" ("HostMealId", "HostId", "CuisineId", "DishName", "EventDate", "EventStartTime", "EventEndTime", "BookBeforeDate", "BookBeforeTime", "Price", "Currency", "MealImage", "MaximumGuest", "Description", "IsActive", "IsDeleted", "CreatedAt", "UpdatedAt", "IsDineIn", "IsHomeDelivery", "IsTakeAway", "MealImageUrl") FROM stdin;
7	3	4	Masla Dal	2025-12-02	08:21:00	09:40:00	2025-12-02	02:23:00	1892.00	INR	\N	4	spicy namkeen	t	f	2025-12-02 05:50:24.690817	2025-12-02 05:50:24.690817	t	t	t	\N
8	3	4	Masla Dal	2025-12-02	08:21:00	09:40:00	2025-12-02	02:23:00	1892.00	INR	\N	4	spicy namkeen	t	f	2025-12-02 05:52:05.695344	2025-12-02 05:52:10.901348	t	t	t	https://safroo.blob.core.windows.net/meal-image/74cd9f5a-7b28-40ec-ac4e-f4d30bafea77.png
9	3	6	Pooran	2025-12-02	09:21:00	12:02:00	2025-12-02	06:22:00	233.00	INR	\N	23	ssdedwwdqqqqqqqqqqqqqqqqqqqqqqqqqqq3	t	f	2025-12-02 07:30:54.204421	2025-12-02 07:31:02.152323	t	t	t	https://safroo.blob.core.windows.net/meal-image/63edff48-a96e-434b-bbde-8badf159fe52.jpeg
1	1	3	Authentic Butter Chicken	2025-12-15	19:00:00	21:00:00	2025-12-14	15:00:00	499.00	INR	butter-chicken.jpg	5	A rich and creamy North Indian curry served with naan and rice. Prepared using homemade spices.	t	f	2025-11-26 18:05:38.361943	2025-11-26 18:05:38.361943	t	t	t	\N
6	3	4	Masla Dal	2025-12-02	08:21:00	09:40:00	2025-12-02	02:23:00	1892.00	INR	\N	4	spicy namkeen	t	f	2025-12-02 05:48:41.382727	2025-12-02 05:48:41.382727	t	f	t	\N
\.


--
-- Data for Name: HostRatings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."HostRatings" ("RatingId", "HostId", "GuestId", "BookingId", "ValueForMoney", "Hygiene", "Food", "ReviewComment", "CreatedAt", "UpdatedAt", "IsActive", "IsDeleted") FROM stdin;
1	3	44	2001	4	5	4	Very good meal, hygiene was excellent.	2025-12-02 06:23:11.881345	2025-12-02 06:23:11.881345	t	f
2	3	45	2002	5	5	5	Amazing experience! Highly recommended.	2025-12-02 06:23:11.881345	2025-12-02 06:23:11.881345	t	f
3	3	46	2003	3	4	4	Good food, decent hygiene.	2025-12-02 06:23:11.881345	2025-12-02 06:23:11.881345	t	f
4	3	44	2004	5	5	5	Perfect in all aspects. Loved it!	2025-12-02 06:23:11.881345	2025-12-02 06:23:11.881345	t	f
11	3	71	8	3	2	3	avrage	2025-12-26 06:40:50.091038	2025-12-26 06:40:50.091038	t	f
\.


--
-- Data for Name: Hosts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Hosts" ("HostId", "UserId", "FoodLicence", "IdProof", "IsDeleted", "CreatedAt", "UpdatedAt", "KitchenName", "HostDescription", "IsApproved", "IsRejected", "RejectedReasonId", "OptionalReason") FROM stdin;
3	72	https://safroo.blob.core.windows.net/host-documents/0e485662-d58a-4551-9848-e752447f8e84.svg	https://safroo.blob.core.windows.net/host-documents/9408df22-b85d-42e3-9173-c5197d1e8c1d.HEIC	f	2025-12-02 05:46:45.526679	2025-12-24 06:29:33.890834	Maharaja Kitchen	Serving customer since 1928 ..Still No complaint	t	f	\N	\N
2	5	\N	\N	f	2025-11-29 08:35:27.879566	2025-12-08 09:00:26.793705	\N	\N	f	t	4	
1	66	foodlicence.jpg	idproof.jpg	f	2025-11-26 17:51:22.50374	2025-12-09 06:17:01.129843	\N	\N	f	t	6	
\.


--
-- Data for Name: MasterDiningType; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MasterDiningType" ("DiningTypeId", "DiningType", "IsDeleted", "CreatedAt", "UpdatedAt") FROM stdin;
1	Dine At Host House	f	2025-11-26 17:45:47.826319	2025-11-26 17:45:47.826319
2	Take Away	f	2025-11-26 17:45:47.826319	2025-11-26 17:45:47.826319
3	Home Delivery	f	2025-11-26 17:45:47.826319	2025-11-26 17:45:47.826319
\.


--
-- Data for Name: MasterReasonCategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MasterReasonCategory" ("ReasonCategoryId", "CategoryName", "CreatedAt", "IsDeleted") FROM stdin;
1	Identity & Document Issues	2025-12-02 16:00:01.194803	f
2	Incomplete or Invalid Application Information	2025-12-02 16:00:01.194803	f
3	Policy Violations or Platform Integrity Concerns	2025-12-02 16:00:01.194803	f
\.


--
-- Data for Name: MasterRoles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MasterRoles" ("RoleId", "RoleName", "IsDeleted", "CreatedAt", "UpdatedAt") FROM stdin;
1	Admin	f	2025-11-18 11:13:03.023	\N
2	Host	f	2025-11-18 11:15:14.088	\N
3	Guest	f	2025-11-18 11:15:44.664	\N
\.


--
-- Data for Name: MealRequests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MealRequests" ("MealRequestId", "GuestUserId", "CuisineId", "DishName", "DiningId", "EventDate", "EventTime", "NoOfGuest", "Description", "IsAccepted", "IsDeleted", "CreatedAt", "UpdatedAt") FROM stdin;
3	71	4	kaka che pohe	2	2025-12-15	20:40:00	2	full rassa	f	f	2025-12-13 13:10:28.936915	2025-12-13 13:10:28.936915
4	71	7	kk	2	2025-12-15	20:49:00	2	kojk	f	f	2025-12-13 13:19:51.094341	2025-12-13 13:19:51.094341
5	71	4	kjh	2	2025-12-25	20:51:00	2	ghgh	f	f	2025-12-13 13:21:08.027997	2025-12-13 13:21:08.027997
6	71	4	eew	0	2025-12-18	19:03:00	2	ss	f	f	2025-12-13 13:33:40.254626	2025-12-13 13:33:40.254626
7	71	4	khara bhaji	1	2025-12-10	21:03:00	2	ss	f	f	2025-12-13 13:34:05.102064	2025-12-13 13:34:05.102064
1	71	4	Besan Bhakar	2	2025-11-29	07:09:00	2	Spicy	t	f	2025-11-29 09:34:43.860542	2025-12-17 06:42:00.288985
2	71	6	Khicdi	2	2025-12-13	09:02:00	2	Salted	t	f	2025-12-13 10:46:11.240306	2025-12-24 06:44:29.180276
\.


--
-- Data for Name: MediaStorage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MediaStorage" ("MediaStorageId", "UserId", "MediaName", "MediaType", "MediaBlobId", "MediaURL", "CreatedAt", "IsActive") FROM stdin;
1	1	user-profile	Image	c5be1839-075b-40b3-99c5-0ebe765d6abc	https://safroo.blob.core.windows.net/user-profile/c5be1839-075b-40b3-99c5-0ebe765d6abc.jpg	2025-11-11 11:55:54.647931+00	t
2	1	user-profile	Image	ad9c6cd9-b90f-41e9-a919-5ca513d996ca	https://safroo.blob.core.windows.net/user-profile/ad9c6cd9-b90f-41e9-a919-5ca513d996ca.svg	2025-11-12 05:39:43.408867+00	t
3	14433	user-profile	Image	49174401-a164-489c-9df4-dacbf7a1cc91	https://safroo.blob.core.windows.net/user-profile/49174401-a164-489c-9df4-dacbf7a1cc91.svg	2025-11-12 05:40:06.936612+00	t
4	1	user-profile	Image	b8fced0e-6ea2-4d9a-bf71-442c1a9a4592	https://safroo.blob.core.windows.net/user-profile/b8fced0e-6ea2-4d9a-bf71-442c1a9a4592.svg	2025-11-12 05:40:20.450695+00	t
5	4	cuisine-image	Image	69e149a1-b7c5-43a4-91b8-45be53bf7018	https://safroo.blob.core.windows.net/cuisine-image/69e149a1-b7c5-43a4-91b8-45be53bf7018.avif	2025-11-25 06:10:29.845078+00	t
6	71	user-profile	Image	21be541c-49d5-4948-bc71-34e8dfbf88bc	https://safroo.blob.core.windows.net/user-profile/21be541c-49d5-4948-bc71-34e8dfbf88bc.avif	2025-12-02 05:40:47.91113+00	t
7	8	meal-image	Image	74cd9f5a-7b28-40ec-ac4e-f4d30bafea77	https://safroo.blob.core.windows.net/meal-image/74cd9f5a-7b28-40ec-ac4e-f4d30bafea77.png	2025-12-02 05:52:11.929223+00	t
8	72	user-profile	Image	428b27e7-9826-4a72-ae01-30eeffc4574f	https://safroo.blob.core.windows.net/user-profile/428b27e7-9826-4a72-ae01-30eeffc4574f.png	2025-12-02 06:16:37.313191+00	t
9	9	meal-image	Image	63edff48-a96e-434b-bbde-8badf159fe52	https://safroo.blob.core.windows.net/meal-image/63edff48-a96e-434b-bbde-8badf159fe52.jpeg	2025-12-02 07:31:03.156226+00	t
10	71	user-profile	Image	fa8b20e7-cb25-449d-9589-78e1d4f9b369	https://blobstoragehomebite.blob.core.windows.net/user-profile/fa8b20e7-cb25-449d-9589-78e1d4f9b369.jpg	2025-12-26 09:44:29.126014+00	t
11	11	cuisine-image	Image	886fbfae-b719-497f-8b96-9223be6156b1	https://blobstoragehomebite.blob.core.windows.net/cuisine-image/886fbfae-b719-497f-8b96-9223be6156b1.png	2025-12-26 09:52:40.583125+00	t
\.


--
-- Data for Name: RejectionReasons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RejectionReasons" ("ReasonId", "ReasonCategoryId", "ReasonText", "CreatedAt", "IsDeleted") FROM stdin;
1	1	National ID/Passport/License is expired	2025-12-02 16:00:39.984976	f
2	1	Uploaded documents are blurry or unreadable	2025-12-02 16:00:39.984976	f
3	1	Mismatch between profile details and document (e.g. name, photo, country)	2025-12-02 16:00:39.984976	f
4	1	Document is not an accepted type (e.g., not a government-issued ID)	2025-12-02 16:00:39.984976	f
5	1	Forgery or suspected tampering of document	2025-12-02 16:00:39.984976	f
6	2	Profile photo does not meet standards (e.g., not a clear headshot or non-professional image)	2025-12-02 16:00:56.131769	f
7	2	Provided email or phone number is invalid or unreachable	2025-12-02 16:00:56.131769	f
8	3	User has a duplicate account	2025-12-02 16:01:05.947977	f
9	3	Terms of use violation discovered during the review	2025-12-02 16:01:05.947977	f
10	3	Refusal to comply with platform's background check process	2025-12-02 16:01:05.947977	f
\.


--
-- Data for Name: RequestQuotes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RequestQuotes" ("QuoteId", "MealRequestId", "HostId", "QuotedPrice", "Currency", "Message", "Status", "ValidUntil", "CreatedAt", "UpdatedAt", "IsDeleted") FROM stdin;
1	1	3	1500.00	INR	Home-cooked dinner for 2 people	ACCEPTED	2025-12-01 18:00:00	2025-11-29 10:32:44.064657	2025-12-17 06:42:00.288985	t
2	2	3	120.00	INR	Added Flavours	ACCEPTED	2025-12-23 05:40:48.018	2025-12-23 05:42:13.09543	2025-12-24 06:44:29.180276	t
\.


--
-- Data for Name: UserAddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."UserAddress" ("AddressId", "UserId", "FlatHouseNo", "BuildingName", "StreetLocality", "Landmark", "Pincode", "State", "CreatedAt", "UpdatedAt") FROM stdin;
1	0	string	string	string	string	string	string	2025-11-11 14:43:52.046327	2025-11-11 14:43:52.046327
2	0	string	string	string	string	string	string	2025-11-11 15:17:28.160574	2025-11-11 15:17:28.160574
3	68	string	string	string	string	string	string	2025-11-11 15:17:48.164844	2025-11-11 15:17:48.164844
4	2	string	string	string	string	string	string	2025-11-11 15:19:29.85601	2025-11-11 15:19:29.85601
5	17	dwws	w	sw	w	www	wq	2025-11-11 16:14:35.885708	2025-11-11 16:14:35.885708
6	33	dwws	w	sw	w	www	wq	2025-11-12 12:36:20.179674	2025-11-12 12:36:20.179674
7	36	dwws	w	sw	w	www	wq	2025-11-12 15:24:30.00335	2025-11-12 15:24:30.00335
8	0	string	string	string	string	string	string	2025-11-12 18:11:24.843151	2025-11-12 18:11:24.843151
9	44	Flat no 1	rajaram mohan roy 	ajmer street	new t2 	444203	Maharashtra	2025-11-12 18:28:28.929698	2025-11-12 18:28:28.929698
10	45	Flat no 1	rajaram mohan roy 	ajmer street	new t2 	444203	Mizoram	2025-11-12 19:37:27.634948	2025-11-12 19:37:27.634948
11	45	Flat no 1	rajaram mohan roy 	ajmer street	new t2 	444203	Mizoram	2025-11-12 19:37:46.62347	2025-11-12 19:37:46.62347
12	46	Flat no 1	rajaram mohan roy 	ajmer street	new t2 	444203	Maharashtra	2025-11-12 19:43:36.152413	2025-11-12 19:43:36.152413
13	47	Flat no 1	rajaram mohan roy 	ajmer street	new t2 	444203	Maharashtra	2025-11-12 19:53:17.403091	2025-11-12 19:53:17.403091
14	48	Flat no 3	rajaram mohan roy 	ajmer street	new t2 	444203	Maharashtra	2025-11-12 21:40:24.159756	2025-11-12 21:40:24.159756
15	49	Flat no 5	rajaram mohan roy 	ajmer street	new t2 	444203	Maharashtra	2025-11-13 11:06:47.932535	2025-11-13 11:06:47.932535
16	51	Flat no 9	rajaram mohan roy 	ajmer street	new t2 	444520	Maharashtra	2025-11-13 12:02:40.628603	2025-11-13 12:02:40.628603
17	52	Flat no 9	rajaram mohan roy 	ajmer street	new t2 	425624	Maharashtra	2025-11-13 12:15:24.975629	2025-11-13 12:15:24.975629
18	53	Flat no 5	rajaram mohan roy 	ajmer street	new t2 	541256	Maharashtra	2025-11-13 13:51:03.50149	2025-11-13 13:51:03.50149
19	54	Flat no 5	rajaram mohan roy 	ajmer street	new t2 	545124	Maharashtra	2025-11-13 14:07:40.902658	2025-11-13 14:07:40.902658
20	55	Flat no 3	rajaram mohan roy 	ajmer street	new t2 	458754	Maharashtra	2025-11-13 17:48:12.666667	2025-11-13 17:48:12.666667
21	56	Flat no 9	rajaram mohan roy 	ajmer street	new t2 	547855	Maharashtra	2025-11-13 18:21:39.026458	2025-11-13 18:21:39.026458
22	57	Flat no 9	rajaram mohan roy 	ajmer street	new t2 	589658	Maharashtra	2025-11-13 19:26:02.22863	2025-11-13 19:26:02.22863
23	58	Flat no 9	rajaram mohan roy 	ajmer street	new t2 	547789	Maharashtra	2025-11-13 19:40:54.280576	2025-11-13 19:40:54.280576
24	60	Flat no 9	rajaram mohan roy 	ajmer street	new t2 	547854	Maharashtra	2025-11-14 11:13:50.460052	2025-11-14 11:13:50.460052
25	61	Flat no 9	rajaram mohan roy 	ajmer street	new t2 	547854	Maharashtra	2025-11-14 13:57:50.36474	2025-11-14 13:57:50.36474
26	62	dfdasfas	sdfsafa	sdfasdfas	sdfasfasfa	541254	Maharashtra	2025-11-14 14:45:05.780283	2025-11-14 14:45:05.780283
27	63	asdfasdfa	asdfafas	sfasfsafa	new t2 	547854	Maharashtra	2025-11-15 12:02:24.558042	2025-11-15 12:02:24.558042
28	66	ss	ssw	w	ww	ww	ee	2025-11-25 14:12:58.235776	2025-11-25 14:12:58.235776
29	66	ss	ssw	w	ww	ww	ee	2025-11-25 14:13:20.734961	2025-11-25 14:13:20.734961
30	67	pyramid county	a1 bulding	bhukum	bhukum	12345	Maharastra	2025-11-25 15:08:43.851714	2025-11-25 15:08:43.851714
31	69	Host House 302	pyramid	Bhukum	TiTu	425003	maharastra	2025-11-29 11:18:28.969297	2025-11-29 11:18:28.969297
32	70	Guest House 302	pyramid	Bhukum	TiTu	425003	maharastra	2025-11-29 11:20:48.018217	2025-11-29 11:20:48.018217
33	71	Not Found	pyramid	string	Bhukum	412115	maharastra	2025-12-02 05:53:18.593689	2025-12-02 05:53:18.593689
34	72	Not Found	pyramid	string	Bhukum	412115	maharastra	2025-12-02 05:53:26.621688	2025-12-02 05:53:26.621688
\.


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Users" ("UserId", "FirstName", "LastName", "Email", "PhoneNumber", "RoleId", "PasswordHash", "Gender", "Country", "ProfilePhotoUrl", "IsEmailVerified", "IsPhoneNumberVerified", "IsDeactivate", "CreatedAt", "UpdatedAt", "DeactivatedBy", "DisplayName", "CountryCode", "DialCode") FROM stdin;
35	swqea	dsfsdaf	harshaan.drace@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	f	f	f	2025-11-12 15:07:45.085	2025-11-12 15:07:47.395	\N	\N	\N	\N
6	\N	\N	tepeho3071@wivstore.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	\N	\N	\N	t	f	f	2025-11-10 18:12:37.76	2025-11-10 18:12:39.713	\N	\N	\N	\N
5	\N	\N	woyito9775@wivstore.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	\N	\N	https://safroo.blob.core.windows.net/user-profile/a2d3fde3-5935-4a58-b05f-e58e3b599e89.jpg	t	f	f	2025-11-10 17:49:32.761	2025-11-10 17:49:34.963	\N	\N	\N	\N
29	sds	sdsd	yisaben119@chaineor.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	f	f	f	2025-11-12 12:00:02.926	2025-11-12 12:00:05.181	\N	\N	\N	\N
7	\N	\N	mivijo2484@burangir.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	\N	\N	\N	t	f	f	2025-11-11 12:12:59.742	2025-11-11 12:37:56.996	\N	\N	\N	\N
9	\N	\N	adityadahake392002@gmail.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	f	f	f	2025-11-11 15:08:22.721	2025-11-11 15:08:24.911	\N	\N	\N	\N
10	\N	\N	sultan.jamair@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	f	f	f	2025-11-11 15:16:10.336	2025-11-11 15:16:12.336	\N	\N	\N	\N
30	dfd	dfdf	geyetiy150@chaineor.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	f	f	f	2025-11-12 12:12:38.383	2025-11-12 12:12:40.214	\N	\N	\N	\N
8	rahul	jad	barker.henning@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-11 14:10:32.6	2025-11-11 14:10:34.853	\N	\N	\N	\N
11	\N	\N	jonmichael.taneesh@fontfee.com	\N	2	40b192792c0fceab62ef7205c2610354a1cac2c15f2978e270a5270d48f58d23	\N	\N	\N	f	f	f	2025-11-11 15:29:53.9	2025-11-11 15:29:56.15	\N	\N	\N	\N
12	\N	\N	jaevian.leeson@fontfee.com	\N	2	4a20c0427422e8affa695c423182ec3cf980e17bdce62a126075277d022b3b8a	\N	\N	\N	f	f	f	2025-11-11 15:35:49.186	2025-11-11 15:35:51.551	\N	\N	\N	\N
13	\N	\N	nahim89576@fandoe.com	\N	2	cfe31f06c3bb604111c55c65ed04511e5dd9bc2e1cbdf48aa2c680f6f7f086cc	\N	\N	\N	t	f	f	2025-11-11 15:42:28.896	2025-11-11 15:42:31.569	\N	\N	\N	\N
14	\N	\N	renowiv599@limtu.com	\N	2	1556089f730b2e1a65c0b914f25cda2cbf7ed38a867b4d85e790e49a6f3d7833	\N	\N	\N	f	f	f	2025-11-11 15:50:13.852	2025-11-11 15:50:15.739	\N	\N	\N	\N
15	\N	\N	pivac69943@burangir.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	\N	\N	\N	t	f	f	2025-11-11 15:53:58.91	2025-11-11 15:54:00.89	\N	\N	\N	\N
16	\N	\N	soyahal269@fandoe.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	f	f	f	2025-11-11 16:07:18.442	2025-11-11 16:07:20.41	\N	\N	\N	\N
17	omkar	zeole	leyeb28773@burangir.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	Female	\N	\N	t	f	f	2025-11-11 16:13:31.417	2025-11-11 16:13:33.265	\N	\N	\N	\N
18	\N	\N	hesox71269@fandoe.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	f	f	f	2025-11-11 16:32:54.894	2025-11-11 16:32:56.941	\N	\N	\N	\N
19	\N	\N	johob65169@limtu.com	\N	2	9bda4b3ad8634f9c3311fc630bfb19b58cd34a72104df4d925b31891a51581e1	\N	\N	\N	f	f	f	2025-11-11 16:36:00.058	2025-11-11 16:36:01.908	\N	\N	\N	\N
20	\N	\N	lopeses590@limtu.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	f	f	f	2025-11-11 16:40:23.142	2025-11-11 16:40:25.105	\N	\N	\N	\N
21	\N	\N	mojes30936@limtu.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	f	f	f	2025-11-11 16:42:07.584	2025-11-11 16:42:09.444	\N	\N	\N	\N
22	\N	\N	jicad17758@limtu.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	f	f	f	2025-11-11 16:43:53.578	2025-11-11 16:43:55.455	\N	\N	\N	\N
23	\N	\N	menip88519@fandoe.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	f	f	f	2025-11-11 16:56:09.857	2025-11-11 16:56:11.792	\N	\N	\N	\N
24	\N	\N	wivot57007@limtu.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	f	f	f	2025-11-11 16:58:00.337	2025-11-11 16:58:02.156	\N	\N	\N	\N
25	\N	\N	tijirak904@fandoe.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	f	f	f	2025-11-11 16:59:48.709	2025-11-11 16:59:50.534	\N	\N	\N	\N
26	\N	\N	leron39746@chaineor.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	f	f	f	2025-11-11 19:48:15.419	2025-11-11 19:48:17.619	\N	\N	\N	\N
27	\N	\N	temase3060@chaineor.com	\N	2	d775733141dfa3e2f4eca2512b9929d58e2e89a36b0adb50f0a16db98a1634a2	\N	\N	\N	f	f	f	2025-11-11 20:02:05.655	2025-11-11 20:02:07.353	\N	\N	\N	\N
28	Saurabh	Nale	hakan58079@delaeb.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	f	f	f	2025-11-12 10:34:04.92	2025-11-12 10:34:07.18	\N	\N	\N	\N
31	dfdf	dad	nicana9851@delaeb.com	\N	2	d2c96e413e7c1fcdcea0c083012796e0606fe81eaf78d798aceaed65fbd64d63		\N	\N	f	f	f	2025-11-12 12:21:57.156	2025-11-12 12:21:59.128	\N	\N	\N	\N
32	sdfdssd	dfsa	nelit92813@chaineor.com	\N	2	962a667907b527151aafe47ff5e540ddf10e850d0e90b8dccda4baca7abe3b17		\N	\N	f	f	f	2025-11-12 12:26:49.59	2025-11-12 12:26:51.594	\N	\N	\N	\N
39	fdfsafasf	adfasfasf	kairi.kline@fontfee.com	\N	2	f4ec7e8271df452e4d8fa5ba4253c3d66f545357715df579509f3a1dd7bf5551		\N	\N	f	f	f	2025-11-12 16:16:52.04	2025-11-12 16:16:54.004	\N	\N	\N	\N
34	dads	sdfsafa	cibijin761@delaeb.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	f	f	f	2025-11-12 13:04:00.377	2025-11-12 13:04:02.453	\N	\N	\N	\N
36	omkar	zeole	sidelem381@gyknife.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	Other	\N	\N	t	f	f	2025-11-12 15:24:00.486	2025-11-12 15:24:02.2	\N	\N	\N	\N
37	sdfsdfas	dfsfasd	navraj.seidon@fontfee.com	\N	2	d4e4d268b8277b7440e7c6e2490f7e480977570375c75db8b0a49e5ba4456576		\N	\N	f	f	f	2025-11-12 15:45:00.241	2025-11-12 15:45:02.66	\N	\N	\N	\N
38	dsfadsfas	afdsdfasdf	jarrett.caylor@fontfee.com	\N	2	5be6fa97a72f0cd99dab83180ebc5048aa63c5be7b2879f06621ea80b6540a61		\N	\N	f	f	f	2025-11-12 16:12:29.472	2025-11-12 16:12:31.565	\N	\N	\N	\N
40	Vikrant	Rona	jaskirat.jessi@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	f	f	f	2025-11-12 16:52:05.06	2025-11-12 16:52:07.528	\N	\N	\N	\N
41	\N	\N	maleki.dmitry@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	t	f	f	2025-11-12 16:55:38.261	2025-11-12 16:55:40.885	\N	\N	\N	\N
42	sunny	Deol	takota.camari@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-12 17:15:17.474	2025-11-12 17:15:19.637	\N	\N	\N	\N
44	ajay	atul	johnpatrick.salah@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-12 18:25:56.268	2025-11-12 18:25:58.498	\N	\N	\N	\N
45	my name is	what	joeray.ralston@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-12 19:36:32.919	2025-11-12 19:36:35.549	\N	\N	\N	\N
46	asdfsdfsa	asdfsafas	mychael.tobin@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-12 19:42:59.774	2025-11-12 19:43:01.935	\N	\N	\N	\N
47	dfdsfa	adfasdfa	darsh.jaquay@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-12 19:52:30.799	2025-11-12 19:52:33.217	\N	\N	\N	\N
48	Adtiya	Dahake	malachai.bryar@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-12 21:39:02.73	2025-11-12 21:39:05.195	\N	\N	\N	\N
4	suresh	Maama	abhay@gmail.com	\N	3	6fef90d84745c79e06b2909ee1ca5aa2eca7e01812e3ccd55f9c5c1f871e8fbe	Male	\N	\N	f	f	t	2025-11-10 16:26:03.71	2025-12-08 13:26:23.923	12	\N	\N	\N
43	Akshay	Khanna	yogep84558@gyknife.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	\N	\N	\N	f	f	f	2025-11-12 18:08:14.882	2025-11-12 18:08:21.268	\N	\N	\N	\N
33	omkar	zeole	hovodiv469@etramay.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	Female	\N	\N	t	f	f	2025-11-12 12:35:38.783	2025-12-08 13:28:31.073	0	\N	\N	\N
49	Rahul	Jadhav	tyre.malcom@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-13 11:05:27.409	2025-11-13 11:05:29.904	\N	\N	\N	\N
50	dgsdgdfg	adfasfda	zadyn.anis@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-13 11:39:25.223	2025-11-13 11:39:27.579	\N	\N	\N	\N
51	gafasd	sdfasfa	omari.khamarion@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-13 11:56:35.052	2025-11-13 11:56:37.383	\N	\N	\N	\N
62	dsdfadsf	sdfsafas	kejal87394@delaeb.com	\N	2	1a5376ad727d65213a79f3108541cf95012969a0d3064f108b5dd6e7f8c19b89		\N	\N	t	f	f	2025-11-14 14:44:30.136	2025-11-14 15:10:29.455	\N	\N	\N	\N
52	sdafsaf	sdfsaf	akshar.esmond@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-13 12:11:47.996	2025-11-13 12:11:50.141	\N	\N	\N	\N
53	cfsfdsd	sdsds	luisangel.raleigh@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-13 13:50:17.779	2025-11-13 13:50:20.073	\N	\N	\N	\N
54	fdgsg	sdgsdg	mykai.roderick@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-13 14:05:43.537	2025-11-13 14:05:45.841	\N	\N	\N	\N
63	dfsdfa	sdafafa	piriboy835@delaeb.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-15 11:55:15.085	2025-11-15 11:55:17.009	\N	\N	\N	\N
55	dsfsad	sdfgds	kingjames.jyquan@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-13 17:47:27.451	2025-11-13 17:47:29.83	\N	\N	\N	\N
56	sdfsdaf	sadfsafa	janniel.prestyn@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-13 18:20:53.296	2025-11-13 18:20:55.65	\N	\N	\N	\N
57	afda	dfas	stanton.rudra@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-13 19:25:25.793	2025-11-13 19:25:28.518	\N	\N	\N	\N
58	sdafasf	sfasdf	kacyn.everett@fontfee.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-13 19:40:16.36	2025-11-13 19:40:18.197	\N	\N	\N	\N
59	\N	\N	yimimop247@chaineor.com	\N	2	e4a0a90e5ac07d5435c6f25c4cf7cc565becb797bb5b83c515bc427ef32a4770	\N	\N	\N	t	f	f	2025-11-13 23:53:59.664	2025-11-14 00:04:06.453	\N	\N	\N	\N
60	raj	Kundra	wivek55053@delaeb.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-14 11:13:09.66	2025-11-14 11:13:11.577	\N	\N	\N	\N
61	new	new	tamow98347@delaeb.com	\N	2	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225		\N	\N	t	f	f	2025-11-14 13:57:06.691	2025-11-14 14:39:27.057	\N	\N	\N	\N
64	\N	\N	cefina5223@gusronk.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	\N	\N	\N	f	f	f	2025-11-18 15:15:35.46	2025-11-18 15:15:37.406	\N	\N	\N	\N
65	\N	\N	cefina5223@gusronk.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	\N	\N	\N	t	f	f	2025-11-18 15:37:32.321	2025-11-18 15:37:34.12	\N	\N	\N	\N
67	abhay	rajput	hafep84146@bablace.com	\N	3	8a9bcf1e51e812d0af8465a8dbcc9f741064bf0af3b3d08e6b0246437c19f7fb	Male	\N	\N	t	f	f	2025-11-25 15:06:42.328	2025-12-08 13:31:24.144	0	\N	\N	\N
2	\N	\N	saurabhnalepatil@gmail.com	\N	1	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	\N	\N	\N	t	f	f	2025-11-06 14:42:17.679	2025-11-06 14:42:19.841	\N	\N	\N	\N
68	\N	\N	mewejib626@docsfy.com	\N	2	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	\N	\N	\N	f	f	f	2025-11-29 10:42:38.67	2025-11-29 10:42:40.599	\N	\N	\N	\N
72	AbhayRaj 22	Host	dacoho4390@idwager.com	\N	2	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	Male	\N	https://safroo.blob.core.windows.net/user-profile/428b27e7-9826-4a72-ae01-30eeffc4574f.png	t	f	f	2025-12-02 05:41:34.888	2025-12-24 06:33:18.833	0	\N	\N	\N
71	Rahul	Jadhav	caxij23686@httpsu.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	Male	\N	https://blobstoragehomebite.blob.core.windows.net/user-profile/fa8b20e7-cb25-449d-9589-78e1d4f9b369.jpg	t	f	f	2025-12-02 05:39:13.891	2025-12-08 13:41:13.675	0	\N	\N	\N
70	\N	\N	fowabi1545@datehype.com	\N	2	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	\N	\N	\N	t	f	f	2025-11-29 11:19:42.724	2025-11-29 11:19:44.857	\N	\N	\N	\N
66	Satya	Nadelaeddddddddddddd	fohono9311@bablace.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	Female	\N	\N	t	f	f	2025-11-25 14:11:16.826	2025-12-08 13:31:15.394	0	\N	\N	\N
3	\N	\N	livod45816@fantastu.com	\N	1	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	\N	\N	\N	t	f	f	2025-11-06 15:03:07.804	2025-11-06 17:32:48.248	\N	\N	\N	\N
1	\N	\N	saurabhnale1603@gmail.com	\N	1	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	\N	\N	https://safroo.blob.core.windows.net/user-profile/b8fced0e-6ea2-4d9a-bf71-442c1a9a4592.svg	t	f	f	2025-11-06 14:38:06.428	2025-11-06 14:38:32.293	\N	\N	\N	\N
69	Host 	TRial	fehanev780@docsfy.com	\N	3	ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f	Male	\N	\N	t	f	f	2025-11-29 11:15:27.89	2025-12-08 13:31:20.424	0	\N	\N	\N
\.


--
-- Name: Bookings_BookingId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Bookings_BookingId_seq"', 17, true);


--
-- Name: Cuisines_CuisineId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Cuisines_CuisineId_seq"', 11, true);


--
-- Name: HostMeals_HostMealId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."HostMeals_HostMealId_seq"', 9, true);


--
-- Name: HostRatings_RatingId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."HostRatings_RatingId_seq"', 11, true);


--
-- Name: Hosts_HostId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Hosts_HostId_seq"', 3, true);


--
-- Name: MasterDiningType_DiningTypeId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."MasterDiningType_DiningTypeId_seq"', 1, false);


--
-- Name: MasterReasonCategory_ReasonCategoryId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."MasterReasonCategory_ReasonCategoryId_seq"', 3, true);


--
-- Name: MealRequests_MealRequestId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."MealRequests_MealRequestId_seq"', 7, true);


--
-- Name: MediaStorage_MediaStorageId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."MediaStorage_MediaStorageId_seq"', 11, true);


--
-- Name: RejectionReasons_ReasonId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."RejectionReasons_ReasonId_seq"', 10, true);


--
-- Name: RequestQuotes_QuoteId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."RequestQuotes_QuoteId_seq"', 2, true);


--
-- Name: UserAddress_AddressId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."UserAddress_AddressId_seq"', 34, true);


--
-- Name: Users_UserId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Users_UserId_seq"', 72, true);


--
-- Name: Bookings Bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Bookings"
    ADD CONSTRAINT "Bookings_pkey" PRIMARY KEY ("BookingId");


--
-- Name: Cuisines Cuisines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cuisines"
    ADD CONSTRAINT "Cuisines_pkey" PRIMARY KEY ("CuisineId");


--
-- Name: HostMeals HostMeals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HostMeals"
    ADD CONSTRAINT "HostMeals_pkey" PRIMARY KEY ("HostMealId");


--
-- Name: HostRatings HostRatings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HostRatings"
    ADD CONSTRAINT "HostRatings_pkey" PRIMARY KEY ("RatingId");


--
-- Name: Hosts Hosts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Hosts"
    ADD CONSTRAINT "Hosts_pkey" PRIMARY KEY ("HostId");


--
-- Name: MasterDiningType MasterDiningType_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MasterDiningType"
    ADD CONSTRAINT "MasterDiningType_pkey" PRIMARY KEY ("DiningTypeId");


--
-- Name: MasterReasonCategory MasterReasonCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MasterReasonCategory"
    ADD CONSTRAINT "MasterReasonCategory_pkey" PRIMARY KEY ("ReasonCategoryId");


--
-- Name: MasterRoles MasterRoles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MasterRoles"
    ADD CONSTRAINT "MasterRoles_pkey" PRIMARY KEY ("RoleId");


--
-- Name: MealRequests MealRequests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MealRequests"
    ADD CONSTRAINT "MealRequests_pkey" PRIMARY KEY ("MealRequestId");


--
-- Name: MediaStorage MediaStorage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MediaStorage"
    ADD CONSTRAINT "MediaStorage_pkey" PRIMARY KEY ("MediaStorageId");


--
-- Name: RejectionReasons RejectionReasons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RejectionReasons"
    ADD CONSTRAINT "RejectionReasons_pkey" PRIMARY KEY ("ReasonId");


--
-- Name: RequestQuotes RequestQuotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RequestQuotes"
    ADD CONSTRAINT "RequestQuotes_pkey" PRIMARY KEY ("QuoteId");


--
-- Name: UserAddress UserAddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserAddress"
    ADD CONSTRAINT "UserAddress_pkey" PRIMARY KEY ("AddressId");


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY ("UserId");


--
-- Name: RequestQuotes uq_request_host; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RequestQuotes"
    ADD CONSTRAINT uq_request_host UNIQUE ("MealRequestId", "HostId");


--
-- Name: HostMeals fk_cuisine_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HostMeals"
    ADD CONSTRAINT fk_cuisine_id FOREIGN KEY ("CuisineId") REFERENCES public."Cuisines"("CuisineId") ON DELETE CASCADE;


--
-- Name: HostMeals fk_host_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HostMeals"
    ADD CONSTRAINT fk_host_id FOREIGN KEY ("HostId") REFERENCES public."Hosts"("HostId") ON DELETE CASCADE;


--
-- Name: Hosts fk_hosts_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Hosts"
    ADD CONSTRAINT fk_hosts_user FOREIGN KEY ("UserId") REFERENCES public."Users"("UserId") ON DELETE CASCADE;


--
-- Name: MealRequests fk_mealrequests_cuisine; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MealRequests"
    ADD CONSTRAINT fk_mealrequests_cuisine FOREIGN KEY ("CuisineId") REFERENCES public."Cuisines"("CuisineId") ON DELETE SET NULL;


--
-- Name: MealRequests fk_mealrequests_guest; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MealRequests"
    ADD CONSTRAINT fk_mealrequests_guest FOREIGN KEY ("GuestUserId") REFERENCES public."Users"("UserId") ON DELETE CASCADE;


--
-- Name: RejectionReasons fk_reason_category; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RejectionReasons"
    ADD CONSTRAINT fk_reason_category FOREIGN KEY ("ReasonCategoryId") REFERENCES public."MasterReasonCategory"("ReasonCategoryId");


--
-- Name: RequestQuotes fk_requestquotes_host; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RequestQuotes"
    ADD CONSTRAINT fk_requestquotes_host FOREIGN KEY ("HostId") REFERENCES public."Users"("UserId") ON DELETE CASCADE;


--
-- Name: RequestQuotes fk_requestquotes_request; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RequestQuotes"
    ADD CONSTRAINT fk_requestquotes_request FOREIGN KEY ("MealRequestId") REFERENCES public."MealRequests"("MealRequestId") ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict nZ4gRuNfnDPip8eSeQ9EFnf4uCb1JOmEfQ96L5vtdZYrwhQ43xfGIFINRJZzEo7

